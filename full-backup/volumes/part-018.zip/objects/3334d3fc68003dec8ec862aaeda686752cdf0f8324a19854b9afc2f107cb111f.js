/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createLucideIcon from '../createLucideIcon.js';

const __iconNode = [
  ["rect", { width: "10", height: "6", x: "7", y: "9", rx: "2", key: "b1zbii" }],
  ["path", { d: "M22 20H2", key: "1p1f7z" }],
  ["path", { d: "M22 4H2", key: "1b7qnq" }]
];
const AlignVerticalSpaceAround = createLucideIcon("align-vertical-space-around", __iconNode);

export { __iconNode, AlignVerticalSpaceAround as default };
//# sourceMappingURL=align-vertical-space-around.js.map
