/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

export { default } from './square-arrow-out-down-right.js';
//# sourceMappingURL=arrow-down-right-from-square.js.map
