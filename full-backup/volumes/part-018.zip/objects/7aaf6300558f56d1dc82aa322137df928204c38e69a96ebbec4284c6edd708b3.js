/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

import createLucideIcon from '../createLucideIcon.js';

const __iconNode = [
  ["path", { d: "m9 6-6 6 6 6", key: "7v63n9" }],
  ["path", { d: "M3 12h14", key: "13k4hi" }],
  ["path", { d: "M21 19V5", key: "b4bplr" }]
];
const ArrowLeftFromLine = createLucideIcon("arrow-left-from-line", __iconNode);

export { __iconNode, ArrowLeftFromLine as default };
//# sourceMappingURL=arrow-left-from-line.js.map
