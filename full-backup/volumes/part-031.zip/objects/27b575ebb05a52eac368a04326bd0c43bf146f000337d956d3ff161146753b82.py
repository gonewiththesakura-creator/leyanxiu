from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import textwrap
import zipfile
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


WORKSPACE = Path(r"D:\Documents\kimi\workspace")
PROJECT = WORKSPACE / "乐颜秀-换脸App项目"
REPO = PROJECT / "源码" / "app"
SERVER = REPO / "server"
OUT = PROJECT / "部署" / "公司办理技术材料包-2026-08-29"
EVIDENCE = OUT / "08-测试与发布证据"
MAIN_DOCX = OUT / "00-乐颜秀公司办理技术材料册-2026-08-29.docx"
ICP_DOCX = OUT / "01-乐颜秀ICP业务界定-技术事实说明-2026-08-29.docx"
DIAGRAM = OUT / "02-系统架构与数据流图.png"
COMPANY_NAME = "REDACTED_COMPANY_NAME"
COMPANY_CODE = "REDACTED_COMPANY_REGISTRATION"
PROJECT_DATE = "2026-08-29"
COMMIT = "705699261720e658089f5a762de1e30d27f49c75"

BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
LIGHT_BLUE = "E8EEF5"
PALE_BLUE = "F2F7FC"
GREEN = "1F7A57"
PALE_GREEN = "EAF6EF"
AMBER = "A66200"
PALE_AMBER = "FFF4DB"
RED = "B42318"
PALE_RED = "FDECEC"
GRAY = "667085"
LIGHT_GRAY = "F2F4F7"
BLACK = "1D2939"


def run_command(name: str, command: list[str], cwd: Path, env: dict[str, str] | None = None) -> dict:
    merged = os.environ.copy()
    if env:
        merged.update(env)
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            env=merged,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=180,
            check=False,
        )
        output = (completed.stdout or "") + ("\n" + completed.stderr if completed.stderr else "")
        return {"name": name, "exitCode": completed.returncode, "output": output.strip()}
    except Exception as exc:
        return {"name": name, "exitCode": -1, "output": f"command failed: {exc}"}


def safe_env_inventory() -> dict:
    values: dict[str, str] = {}
    env_file = SERVER / ".env"
    if env_file.exists():
        for raw in env_file.read_text(encoding="utf-8", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    safe_keys = [
        "PROVIDER", "PHOTO_PROVIDER", "LLM_PROVIDER", "DEPLOY_ENV", "RELEASE_CHANNEL",
        "AUTH_MODE", "CLOSED_TEST_MODE", "TASKS_BACKEND", "OBJECT_STORAGE_BACKEND",
        "OSS_REGION", "TENCENT_REGION", "DEEPSEEK_MODEL", "PHOTO_EDIT_MODEL", "BAILIAN_MODEL",
        "CONTENT_SAFETY_MODE", "PAYMENT_MODE", "MONITORING_MODE",
    ]
    credential_keys = [
        "WECHAT_APP_ID", "WECHAT_APP_SECRET", "MINIPROGRAM_APPID", "ALIYUN_ACCESS_KEY_ID",
        "ALIYUN_ACCESS_KEY_SECRET", "TENCENT_SECRET_ID", "TENCENT_SECRET_KEY", "VOLC_API_KEY",
        "DASHSCOPE_API_KEY", "DEEPSEEK_API_KEY", "PAYMENT_WEBHOOK_SECRET", "OBJECT_SIGNING_SECRET",
        "AUTH_SESSION_SECRET", "INTERNAL_CRON_TOKEN",
    ]
    return {
        "envFilePresent": env_file.exists(),
        "safeConfiguration": {key: values.get(key) or None for key in safe_keys},
        "credentialPresence": {key: bool(values.get(key)) for key in credential_keys},
        "warning": "仅记录是否存在，不包含任何密钥值；所有既有密钥在正式上线前应由公司账号轮换。",
    }


def collect_evidence() -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    npm = shutil.which("npm.cmd") or shutil.which("npm") or "npm"
    git = shutil.which("git.exe") or shutil.which("git") or "git"
    commands = [
        run_command("server-test", [npm, "test"], SERVER),
        run_command("server-lint", [npm, "run", "lint"], SERVER),
        run_command("web-lint", [npm, "run", "lint"], REPO),
        run_command("web-build", [npm, "run", "build"], REPO),
        run_command("server-sbom", [npm, "run", "sbom"], SERVER),
        run_command("server-audit", [npm, "audit", "--json", "--omit=dev", "--registry=https://registry.npmjs.org"], SERVER),
        run_command("web-audit", [npm, "audit", "--json", "--registry=https://registry.npmjs.org"], REPO),
        run_command(
            "release-check-production",
            [npm, "run", "release:check"],
            SERVER,
            {
                "NODE_ENV": "production",
                "DEPLOY_ENV": "production",
                "VITE_USE_MOCK": "true",
                "RELEASE_TAG": "technical-materials-audit-2026-08-29",
            },
        ),
        run_command("git-state", [git, "status", "--short"], REPO),
        run_command("git-commit", [git, "rev-parse", "HEAD"], REPO),
    ]
    for item in commands:
        suffix = ".json" if item["name"] in {"server-audit", "web-audit", "release-check-production"} else ".txt"
        (EVIDENCE / f"{item['name']}{suffix}").write_text(item["output"] + "\n", encoding="utf-8")
    inventory = safe_env_inventory()
    (EVIDENCE / "safe-environment-inventory.json").write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
    sbom = SERVER / "sbom.cdx.json"
    if sbom.exists():
        shutil.copy2(sbom, EVIDENCE / "sbom.cdx.json")
    summary = {item["name"]: item["exitCode"] for item in commands}
    summary["generatedAt"] = datetime.now().astimezone().isoformat()
    summary["notes"] = {
        "audit": "npm audit 非零表示仍有漏洞，原始 JSON 随包保留；不得把非零改写成通过。",
        "releaseCheck": "生产检查预期非零，证明缺少公司材料时会阻断上线。",
        "git": "工作树不干净时不得生成正式 release tag。",
    }
    (EVIDENCE / "evidence-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"commands": commands, "inventory": inventory, "summary": summary}


def write_csv(path: Path, headers: list[str], rows: list[list[str]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        writer.writerows(rows)


def create_support_files(evidence: dict) -> None:
    route_rows = [
        ["身份", "POST /api/auth/session; POST /api/auth/wechat; GET /api/auth/me; POST /api/auth/logout", "匿名会话仅封闭测试；生产必须微信登录", "用户/服务端", "已实现；公司 AppID/Secret 待配置"],
        ["授权与权利", "GET/POST /api/consents; POST /api/consents/:type/withdraw; DELETE /api/account", "本人会话 + 版本化同意", "用户", "已实现；正式文本待公司批准"],
        ["对象与作品", "GET /api/assets/:assetId/url; DELETE /api/assets/:assetId; GET /api/works", "ownerId 所有权校验 + 短时签名", "用户", "已实现"],
        ["生成", "POST/GET /api/fusion; /api/photo/*; /api/video/matting", "登录 + 人脸同意 + 所有权 + 内容审核 + 权益", "用户", "代码已实现；供应商/样本未全部验收"],
        ["支付", "GET /api/products; POST/GET /api/orders; POST /api/payments/webhook/:provider", "用户会话；回调签名；幂等", "用户/支付方", "账本已实现；生产支付关闭"],
        ["内容安全", "POST /api/moderation/check; 申诉/人工决定/下架接口", "用户会话；内部接口需 x-internal-token", "用户/审核员", "契约已实现；外部审核适配器未接"],
        ["运维", "retention/reconciliation/audits/supplier-deletions/monitoring/alert-drill", "x-internal-token", "技术值班", "已实现；公司需指定值班人并配置令牌"],
        ["公开公示", "GET /api/public/compliance; GET /health; GET /api/readiness", "公开只读；不返回密钥或内部阻断细节", "公众/审核人员", "公示接口已实现；内容待公司批准"],
    ]
    write_csv(OUT / "03-接口与权限矩阵.csv", ["领域", "接口", "控制措施", "调用角色", "当前状态"], route_rows)

    provider_rows = [
        ["视频玩法-经典歌曲/夜景唱歌/跳舞/语录", "/api/fusion", "阿里云（当前主配置）", "MergeVideoModelFace / MergeVideoFace", "上海", "人脸图像、模板标识、任务标识", "默认输入/输出24小时；供应商副本待合同确认", "凭据存在；模板授权与30样本未完成", "阿里云 DPA/删除条款/备案号/资产授权"],
        ["老照片修复", "/api/photo/restore", "阿里云 VIAPI", "EnhanceFace + ColorizeImage", "上海", "人脸照片、处理参数", "默认24小时；供应商副本待合同确认", "代码已接；30样本未完成", "商用范围、删除承诺、质量验收"],
        ["照片融合", "/api/photo/fusion", "阿里云 VIAPI / 百炼候选", "MergeImageFace / 配置图像编辑模型", "上海/待供应商确认", "人脸照片、模板图", "默认24小时", "模板尚未完成生产登记", "模板版权、模型版本、备案号"],
        ["年龄变化", "/api/photo/age", "阿里云 + 腾讯云", "DetectFace + ChangeAgePic", "上海/广州", "人脸照片、目标年龄", "默认24小时", "代码已接；30样本未完成", "腾讯数据删除/训练使用条款"],
        ["AI头像/漫画/艺术效果", "/api/photo/anime; /api/photo/effect", "火山引擎/百炼/阿里云候选", "由生产配置固定", "北京/待供应商确认", "人脸照片、效果ID、提示词", "默认24小时", "多模型候选，尚无逐入口放行证据", "选定唯一生产模型、版本、备案号、成本"],
        ["分享文案", "/api/play/analyze", "DeepSeek（凭据存在时默认）/腾讯混元备选", "deepseek-chat / 配置模型", "供应商控制；待合同确认", "用户输入的作品描述和文案偏好", "代码未声明独立保存期；需公司批准", "仅分享文案，不做玄学/生活类首发", "DPA、跨境/区域、日志保留和训练使用说明"],
        ["内容安全", "/api/moderation/*", "尚未选定外部生产供应商", "本地规则仅封闭测试", "待定", "文本、图片/视频元信息、审核结果", "待公司策略和厂商合同", "生产硬阻断", "采购图像/视频审核服务并完成50组对抗样本"],
    ]
    write_csv(OUT / "04-供应商与功能映射.csv", ["前端功能", "后端路由", "供应商", "模型/能力", "区域", "传输数据", "保存/删除", "当前证据", "公司需补"], provider_rows)

    data_rows = [
        ["账户标识", "微信 openid/unionid 或封闭测试 clientId", "登录、绑定作品和订单", "服务端身份库", "账号存续期；注销后删除/去标识", "微信/无", "公司批准账号注销与客服恢复规则"],
        ["会话令牌", "签名 token、签发/过期时间", "保持登录", "浏览器 sessionStorage + 服务端签名校验", "默认24小时", "无", "生产密钥轮换和失效策略"],
        ["人脸照片", "上传图片、对象ID、MIME、大小", "视频/图片生成", "私有对象存储", "代码默认24小时", "所选影像供应商", "公司确认24小时并写入隐私政策/合同"],
        ["模板视频/图片", "资产ID、模板ID、版权信息", "生成基底", "静态资源/私有存储", "授权期内", "影像供应商", "公司提供资产授权台账"],
        ["生成结果", "图片/视频、内容ID、AI标识元数据", "向用户交付作品", "私有对象存储", "代码默认24小时", "影像供应商", "公司确认下载后/到期删除口径"],
        ["任务记录", "taskId、ownerId、provider taskId、状态、错误码", "轮询、退款、审计", "服务端任务台账", "需公司批准，建议不短于争议处理期且去除人脸原文", "供应商", "确定保留期"],
        ["同意记录", "协议版本、目的、数据类型、供应商、动作、时间", "证明授权与撤回", "合规台账", "法定义务/争议处理所需期限，待法务批准", "无", "批准版本号和保留期"],
        ["订单与权益", "产品、金额、币种、支付事件、退款、积分流水", "发货、退款、对账", "服务端账本", "按财税/争议处理要求，待财务法务确定", "支付机构", "商户号、价格、退款与开票规则"],
        ["内容审核", "输入/输出判断、命中类别、申诉、人工决定", "阻断违法/侵权内容", "审核台账", "待内容安全策略批准", "内容安全供应商（待定）", "策略版本、SLA、审核员"],
        ["安全与运维日志", "requestId、接口、状态、时延、告警、管理员操作", "安全审计和故障处置", "日志/监控系统", "按最小必要原则，待公司批准", "监控服务（待定）", "责任人、保存期、告警渠道"],
        ["分享文案输入", "作品类型、语气、作品描述", "生成分享文案", "服务端临时请求/供应商", "目前未定义独立保存期", "DeepSeek/混元", "明确不上传原始照片；确认供应商日志/训练条款"],
    ]
    write_csv(OUT / "05-数据字段-目的-保存删除清单.csv", ["数据类别", "字段/示例", "目的", "存储位置", "当前/建议保存期", "接收方", "公司需批准"], data_rows)

    company_fields = [
        ["首发渠道", "微信小程序（技术推荐）/iOS/Android/H5", "C01", "待公司签字", "决定备案、支付和包交付路线"],
        ["收费方式", "免费封闭测试/单次/次数包/订阅", "C01/C07", "待公司签字", "当前支付代码保持关闭"],
        ["公司实名域名", "HTTPS 域名", "C04", "待公司购买并实名", "用于 PUBLIC_BASE_URL/CORS/小程序合法域名"],
        ["微信小程序 AppID/Secret", "公司主体账号", "C04/C06", "未配置", "只给技术子权限，不共享主账号密码"],
        ["备案号", "ICP/小程序备案号", "C04", "未取得", "取得后配置并展示"],
        ["隐私政策 URL", "已批准 HTTPS 文档", "C09", "未配置", "PRIVACY_POLICY_URL"],
        ["用户协议 URL", "已批准 HTTPS 文档", "C09", "未配置", "USER_AGREEMENT_URL"],
        ["第三方清单 URL", "已批准 HTTPS 文档", "C09", "未配置", "THIRD_PARTY_LIST_URL"],
        ["PIPIA 编号/版本", "人脸信息处理影响评估", "C09", "未批准", "PIPIA_REFERENCE"],
        ["客服渠道", "电话/邮箱/在线客服", "C09", "未指定", "SUPPORT_CONTACT"],
        ["模型公示", "供应商、模型、备案号、用途、区域", "C08/C09", "待合同核实", "AI_SERVICE_DISCLOSURES_JSON"],
        ["保存期", "输入24h、输出24h、任务/日志/订单各期限", "C08/C09", "待批准", "RETENTION_SUPPLIER_POLICY 与隐私文本一致"],
        ["商户与产品", "商户号、签名密钥、价格、次数、退款", "C07", "未配置", "PAYMENT_MODE=live 前不得收费"],
        ["内容安全供应商", "图像/视频前后置审核", "C09", "未采购", "未接入时生产 NO-GO"],
        ["责任人", "安全/客服/财务/内容/数据事件/值班", "C05/C09", "待公司指定", "姓名、电话、替补和SLA"],
    ]
    write_csv(OUT / "06-生产配置与公司补充字段表.csv", ["字段", "填写内容", "来源项", "当前状态", "技术落点/说明"], company_fields)

    env_template = """# 乐颜秀生产环境公司交付字段模板（不填写真实密钥，不通过聊天传递）
DEPLOY_ENV=production
RELEASE_CHANNEL=wechat-mini-program
AUTH_MODE=wechat
WECHAT_APP_ID=<公司密钥系统引用>
WECHAT_APP_SECRET=<公司密钥系统引用>
MINIPROGRAM_APPID=<公司填写>
MINIPROGRAM_RECORD_NO=<公司填写>
ICP_RECORD_NO=<公司填写>
PUBLIC_BASE_URL=https://<公司实名域名>
CORS_ORIGIN=https://<公司实名域名>
OBJECT_STORAGE_BACKEND=oss
OSS_BUCKET=<公司私有bucket>
OSS_REGION=oss-cn-shanghai
PRIVATE_BUCKET_AUDIT_REPORT=<零公开对象审计报告路径>
AUTH_SESSION_SECRET=<密钥系统引用，至少32字符>
OBJECT_SIGNING_SECRET=<密钥系统引用>
BASIC_CONSENT_VERSION=<公司批准版本>
FACE_CONSENT_VERSION=<公司批准版本>
CONTENT_POLICY_VERSION=<公司批准版本>
PRIVACY_POLICY_URL=https://<已批准隐私政策>
USER_AGREEMENT_URL=https://<已批准用户协议>
THIRD_PARTY_LIST_URL=https://<已批准第三方清单>
PIPIA_REFERENCE=<评估编号/版本>
SUPPORT_CONTACT=<客服电话或邮箱>
AI_SERVICE_DISCLOSURES_JSON=[{"provider":"<公司核实>","model":"<公司核实>","filingReference":"<备案号>","purpose":"<用途>","region":"<区域>"}]
AI_MARKING_REQUIRED=true
SERVICE_PROVIDER_CODE=<公司/服务者编码>
AI_MODEL_FILING_REFERENCE=<公司核实的备案引用>
LICENSED_ASSET_IDS=<已授权模板ID，逗号分隔>
RETENTION_SUPPLIER_POLICY=<公司批准的供应商保存删除政策>
SUPPLIER_DELETION_CAPABILITIES_JSON=<逐供应商删除能力JSON>
CONTENT_SAFETY_MODE=<完成适配的外部审核供应商>
PAYMENT_MODE=closed_test
# 正式收费前另行配置 PAYMENT_PROVIDER/PAYMENT_PRODUCTS_JSON/PAYMENT_WEBHOOK_SECRET
"""
    (OUT / "07-生产配置公司填写模板.txt").write_text(env_template, encoding="utf-8")

    readme = f"""# 乐颜秀公司办理技术材料包

生成日期：{PROJECT_DATE}  
主体：{COMPANY_NAME}（{COMPANY_CODE}）

## 使用顺序

1. 先阅读 `00-乐颜秀公司办理技术材料册-2026-08-29.docx`，逐项完成公司签字字段。
2. 向北京属地监管部门做业务界定时，提交 `01-乐颜秀ICP业务界定-技术事实说明-2026-08-29.docx`，同时附架构图、供应商映射和数据清单。
3. 采购/法务复核供应商时使用 `04-供应商与功能映射.csv`；不得把“凭据存在”当作合同、备案或生产验收完成。
4. 配置生产环境时使用 `06`、`07`，真实密钥只进入公司密钥管理系统，不写入文档、邮件或聊天。
5. `08-测试与发布证据` 保存本次实际命令输出。生产检查非零是预期结果，表示公司材料未齐时系统会阻断上线。

## 边界

- 当前客户端仍是 React/Vite H5，未生成正式原生微信小程序包。
- 当前支付关闭；不得按页面中的测试价格对公众收费。
- 外部内容审核、供应商删除确认、私有 OSS 零公开对象审计和每功能 30 样本仍需公司账号/合同/预算后完成。
- 包内不含密钥值、法人证件、合同原件和公司主账号密码。
"""
    (OUT / "README-使用说明.md").write_text(readme, encoding="utf-8")


def font(size: int) -> ImageFont.FreeTypeFont:
    candidates = [Path(r"C:\Windows\Fonts\msyh.ttc"), Path(r"C:\Windows\Fonts\simhei.ttf"), Path(r"C:\Windows\Fonts\arial.ttf")]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size)
    return ImageFont.load_default()


def create_architecture_diagram() -> None:
    image = Image.new("RGB", (1800, 1080), "#F7F9FC")
    draw = ImageDraw.Draw(image)
    title_font = font(48)
    box_font = font(30)
    small_font = font(23)
    draw.text((80, 42), "乐颜秀系统架构与人脸数据流（当前代码事实）", fill="#17324D", font=title_font)
    draw.text((80, 104), "红色虚线表示仍需公司或供应商完成的生产配置", fill="#B42318", font=small_font)

    def box(x, y, w, h, title, lines, fill_color="#FFFFFF", border="#2E74B5"):
        draw.rounded_rectangle((x, y, x + w, y + h), radius=18, fill=fill_color, outline=border, width=4)
        draw.text((x + 22, y + 18), title, fill="#17324D", font=box_font)
        for idx, line in enumerate(lines):
            draw.text((x + 22, y + 65 + idx * 34), line, fill="#475467", font=small_font)

    def arrow(x1, y1, x2, y2, color="#667085", dashed=False):
        if dashed:
            steps = 12
            for i in range(0, steps, 2):
                xa = x1 + (x2 - x1) * i / steps
                ya = y1 + (y2 - y1) * i / steps
                xb = x1 + (x2 - x1) * (i + 1) / steps
                yb = y1 + (y2 - y1) * (i + 1) / steps
                draw.line((xa, ya, xb, yb), fill=color, width=5)
        else:
            draw.line((x1, y1, x2, y2), fill=color, width=5)
        angle = 13
        if abs(x2 - x1) >= abs(y2 - y1):
            pts = [(x2, y2), (x2 - 22, y2 - angle), (x2 - 22, y2 + angle)] if x2 > x1 else [(x2, y2), (x2 + 22, y2 - angle), (x2 + 22, y2 + angle)]
        else:
            pts = [(x2, y2), (x2 - angle, y2 - 22), (x2 + angle, y2 - 22)] if y2 > y1 else [(x2, y2), (x2 - angle, y2 + 22), (x2 + angle, y2 + 22)]
        draw.polygon(pts, fill=color)

    box(70, 210, 300, 190, "用户端", ["当前：React/Vite H5", "计划：微信小程序", "照片/视频选择与预览"], "#FFFFFF")
    box(460, 185, 360, 240, "API 与访问控制", ["Hono/Node.js", "微信身份/会话/限流", "ownerId 所有权校验", "同意记录与请求ID"], "#EAF2FB")
    box(900, 185, 360, 240, "生成安全管线", ["上传前内容审核", "权益预扣/失败退回", "调用选定 AI 供应商", "输出审核 + AI 标识"], "#EAF6EF", "#1F7A57")
    box(1370, 210, 350, 190, "AI 供应商", ["阿里云（当前主配置）", "腾讯/火山/百炼候选", "DeepSeek 分享文案"], "#FFF4DB", "#A66200")
    box(460, 560, 360, 220, "私有对象存储", ["对象默认私有", "短时签名URL（默认5分钟）", "输入/输出默认24小时", "到期清理与删除回执"], "#EAF2FB")
    box(900, 560, 360, 220, "台账与运维", ["任务/订单/权益/退款", "同意/审核/申诉/审计", "指标、告警、删除重试", "生产 readiness NO-GO"], "#F2F4F7", "#667085")
    box(1370, 575, 350, 190, "公司生产条件", ["公司域名/AppID/备案", "合同/DPA/删除能力", "正式审核与支付", "责任人/值班/密钥轮换"], "#FDECEC", "#B42318")

    arrow(370, 305, 460, 305)
    arrow(820, 305, 900, 305)
    arrow(1260, 305, 1370, 305)
    arrow(1080, 425, 1080, 560)
    arrow(900, 670, 820, 670)
    arrow(640, 560, 640, 425)
    arrow(1370, 670, 1260, 670, color="#B42318", dashed=True)
    arrow(1545, 575, 1545, 400, color="#B42318", dashed=True)
    draw.text((80, 920), "数据主路径：用户照片 → 私有存储 → 短时URL → 供应商处理 → 输出审核/AI标识 → 私有结果 → 用户", fill="#17324D", font=box_font)
    draw.text((80, 976), "当前生产结论：NO-GO。公司凭据、合同、正式域名、小程序包、内容审核和真实样本未齐前不开放公众付费。", fill="#B42318", font=small_font)
    image.save(DIAGRAM, quality=95)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = tr_pr.find(qn("w:cantSplit"))
    if cant_split is None:
        cant_split = OxmlElement("w:cantSplit")
        tr_pr.append(cant_split)


def shade_cell(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def cell_margins(cell, top=80, start=120, bottom=80, end=120) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_cell_width(cell, width_dxa: int) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.find(qn("w:tcW"))
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(width_dxa))
    tc_w.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths: list[int], indent=120) -> None:
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths)))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(indent))
    tbl_ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        prevent_row_split(row)
        for index, cell in enumerate(row.cells):
            set_cell_width(cell, widths[min(index, len(widths) - 1)])
            cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def set_run_font(run, size=11, bold=False, color=BLACK, italic=False) -> None:
    run.font.name = "Calibri"
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = RGBColor.from_string(color)


def configure_document(doc: Document, title: str) -> None:
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.82)
    section.bottom_margin = Inches(0.78)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    section.header_distance = Inches(0.35)
    section.footer_distance = Inches(0.35)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    for name, size, color, before, after in [
        ("Heading 1", 16, BLUE, 18, 10),
        ("Heading 2", 13, BLUE, 14, 7),
        ("Heading 3", 12, DARK_BLUE, 10, 5),
    ]:
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    for name in ["List Bullet", "List Number"]:
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(11)
        style.paragraph_format.left_indent = Inches(0.375)
        style.paragraph_format.first_line_indent = Inches(-0.188)
        style.paragraph_format.space_after = Pt(4)
        style.paragraph_format.line_spacing = 1.25

    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(title)
    set_run_font(run, 8.5, False, GRAY)
    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    fp.paragraph_format.space_before = Pt(0)
    run = fp.add_run(f"{COMPANY_NAME} · {PROJECT_DATE}  |  第 ")
    set_run_font(run, 8.5, False, GRAY)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    fp._p.append(fld)
    run = fp.add_run(" 页")
    set_run_font(run, 8.5, False, GRAY)


def add_title_block(doc: Document, title: str, subtitle: str, status: str) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run("TECHNICAL SUBMISSION PACK")
    set_run_font(r, 9.5, True, BLUE)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(title)
    set_run_font(r, 23, True, BLACK)
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(16)
    r = p.add_run(subtitle)
    set_run_font(r, 13.5, False, GRAY)
    metadata = [
        ("主体", f"{COMPANY_NAME}（{COMPANY_CODE}）"),
        ("项目", "乐颜秀 AI 影像制作服务"),
        ("依据", "《乐颜秀 App 上线整改与许可办理分工手册》C01-C09 技术配合项"),
        ("代码基线", f"Git HEAD {COMMIT[:12]}；当前工作树含未提交整改，正式发布前必须清理并打 tag"),
        ("状态", status),
    ]
    for label, value in metadata:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(f"{label}：")
        set_run_font(r, 10.5, True, BLACK)
        r = p.add_run(value)
        set_run_font(r, 10.5, False, RED if label == "状态" else BLACK)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def add_callout(doc: Document, title: str, text: str, fill=PALE_AMBER, color=AMBER) -> None:
    table = doc.add_table(rows=1, cols=1)
    set_table_geometry(table, [9360])
    cell = table.cell(0, 0)
    shade_cell(cell, fill)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run(title)
    set_run_font(r, 10.5, True, color)
    p = cell.add_paragraph()
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(text)
    set_run_font(r, 10.5, False, BLACK)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_bullet(doc: Document, text: str, bold_prefix: str | None = None) -> None:
    p = doc.add_paragraph(style="List Bullet")
    if bold_prefix and text.startswith(bold_prefix):
        r = p.add_run(bold_prefix)
        set_run_font(r, 11, True, BLACK)
        r = p.add_run(text[len(bold_prefix):])
        set_run_font(r, 11, False, BLACK)
    else:
        r = p.add_run(text)
        set_run_font(r, 11, False, BLACK)


def add_number(doc: Document, text: str) -> None:
    p = doc.add_paragraph(style="List Number")
    r = p.add_run(text)
    set_run_font(r, 11, False, BLACK)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[int], font_size=9.2) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    set_table_geometry(table, widths)
    set_repeat_table_header(table.rows[0])
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        shade_cell(cell, LIGHT_BLUE)
        p = cell.paragraphs[0]
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(header)
        set_run_font(r, font_size, True, DARK_BLUE)
    for row_index, values in enumerate(rows):
        row = table.add_row()
        for index, value in enumerate(values):
            cell = row.cells[index]
            if row_index % 2 == 1:
                shade_cell(cell, "FAFBFC")
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.12
            r = p.add_run(str(value))
            set_run_font(r, font_size, False, BLACK)
    set_table_geometry(table, widths)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def create_main_doc(evidence: dict) -> None:
    doc = Document()
    configure_document(doc, "乐颜秀公司办理技术材料册")
    add_title_block(doc, "乐颜秀公司办理技术材料册", "公司事项所需的技术资料、代码落点、证据附件与待填写字段", "NO-GO：材料已准备，外部账号/审批/合同/正式包仍待公司完成")
    add_callout(doc, "使用原则", "本册把 C01-C09 中技术可以提供的内容全部预填。标为“待公司”的字段必须由公司签字、公司账号或供应商正式回函完成；不得让技术代填法人决定、合同事实、备案号或审批结论。", PALE_BLUE, BLUE)

    doc.add_heading("1. 交付结论与公司立即动作", level=1)
    add_bullet(doc, "技术材料已备齐：真实业务说明、系统架构与数据流、接口权限矩阵、供应商功能映射、数据字段与保存删除清单、生产配置表、测试/SBOM/发布阻断证据。")
    add_bullet(doc, "代码已补强：公开合规信息接口、隐私/协议/第三方/模型备案配置闸门，生产缺项自动 NO-GO；虚构热度已从推荐页移除。")
    add_bullet(doc, "当前不能替公司完成：首发与收费决策、公司域名/AppID/商户号、法律文本批准、供应商合同/删除承诺、内容审核采购、备案提交和正式小程序包主体签名。")
    add_bullet(doc, "公司下一步：按本册第 11 节签字表补齐字段，将批准值交技术进入密钥系统和生产配置；随后才能生成正式包、做真机/支付/私有 OSS 验收。")

    doc.add_heading("2. C01-C09 技术配合完成度", level=1)
    status_rows = [
        ["C01", "渠道与业务边界", "渠道差距、技术推荐、收费/公开能力事实", "已准备", "公司签《首发范围决策单》"],
        ["C02", "ICP 业务界定", "一页业务事实、功能/数据流/供应商/支付", "已准备", "公司提交官方咨询并保存答复"],
        ["C03", "经营范围/许可材料", "业务实施计划、架构、安全与数据保护", "已准备技术底稿", "仅在官方确认需要时提交"],
        ["C04", "域名/备案/包信息", "字段表、接口清单、生产配置契约", "部分完成", "公司域名/AppID/备案；技术仍需原生包"],
        ["C05", "人员材料", "安全职责、权限和应急角色模板", "已准备模板", "公司填实名、劳动关系和联系方式"],
        ["C06", "官方账号权限", "最小权限矩阵和账号移交规则", "已准备", "公司开主账号、MFA、子账号"],
        ["C07", "价格/退款/财务", "订单状态、验签、幂等、退款、对账方案", "代码已具备闭环骨架", "公司定价/商户/退款/开票；真实支付仍关闭"],
        ["C08", "供应商/模型/版权", "实际/候选 provider/model/region 与数据链路", "已脱敏盘点", "公司核合同、DPA、备案号和授权台账"],
        ["C09", "隐私/内容/客服", "数据清单、权利接口、公示接口和生产闸门", "代码与资料已准备", "公司批准文本、PIPIA、客服和审核责任人"],
    ]
    add_table(doc, ["编号", "公司事项", "技术已交付", "状态", "公司下一步"], status_rows, [650, 1500, 2750, 1200, 3260], 8.6)

    doc.add_heading("3. C01 首发渠道与业务边界技术建议", level=1)
    add_callout(doc, "技术推荐（仍需公司签字）", "首发走微信小程序；首期无第三方商家、无用户公开发布/社区、无虚构热度；支付在商户、退款和对账完成前保持关闭。H5 仅作为封闭测试和审核演示，不冒充正式小程序包。", PALE_GREEN, GREEN)
    channel_rows = [
        ["React/Vite H5", "现有可运行", "封闭测试、交互验收", "公司域名、私有OSS、微信身份、正式内容审核", "不能替代小程序备案包"],
        ["微信小程序", "计划首发，尚无原生包", "符合当前产品方向", "原生页面、wx.login、合法域名、隐私接口、备案与审核", "中高改造量"],
        ["iOS", "未开始", "后续可评估", "开发者账号、签名、隐私标签、IAP、真机与商店审核", "高改造量；数字权益必须走IAP"],
        ["Android", "未开始", "后续可评估", "应用市场账号、签名、权限清单、渠道包和隐私标签", "高改造量；多市场规则不同"],
    ]
    add_table(doc, ["渠道", "当前事实", "用途", "还需完成", "主要风险"], channel_rows, [1400, 1700, 1600, 2850, 1810], 8.7)
    doc.add_heading("公司需要签字确认的业务事实", level=2)
    for line in [
        "首发渠道：[ ]微信小程序  [ ]iOS  [ ]Android  [ ]其他：__________",
        "上线地区：__________；目标用户：__________；是否仅中国境内服务：[ ]是 [ ]否",
        "收费：[ ]首期免费封闭测试  [ ]单次  [ ]次数包  [ ]订阅；批准价格另附",
        "首期不开放：[ ]第三方商家入驻  [ ]用户公开作品/社区  [ ]未经证据支持的使用量/热度榜",
        "分享方式：仅用户下载后自行分享；产品内不形成公开内容分发平台，除非公司另行评估并批准。",
    ]:
        add_bullet(doc, line)

    doc.add_heading("4. C02 ICP 业务界定技术事实", level=1)
    add_bullet(doc, "当前产品是公司自营 AI 影像加工工具：用户选择模板并上传本人或已获授权的人脸照片，系统生成视频或图片结果。")
    add_bullet(doc, "当前没有第三方商户入驻、没有用户作品公开社区、没有面向公众的信息发布；推荐页是编辑选定模板，不再显示虚构热度。")
    add_bullet(doc, "当前支付模式为 closed_test，真实收款未开放；会员价格只是测试界面且购买按钮禁用。收费方式须由公司批准后再配置。")
    add_bullet(doc, "当前代码主视频供应商配置为阿里云；腾讯云、火山引擎、百炼等为已具备凭据或候选能力，不等同于全部生产放行。分享文案可调用 DeepSeek。")
    add_bullet(doc, "详细外部咨询稿见附件 01；公司应以官方工单/书面答复为结论，不采信代办口头承诺。")

    doc.add_heading("5. C03 业务实施计划、架构与安全措施", level=1)
    architecture_picture = doc.add_picture(str(DIAGRAM), width=Inches(6.45))
    architecture_picture._inline.docPr.set("title", "乐颜秀系统架构与数据流图")
    architecture_picture._inline.docPr.set(
        "descr",
        "用户端经 API 网关、身份认证、业务服务和私有对象存储调用 AI 供应商；输出经过内容安全与 AI 标识后返回用户，外部账号、合同和审批仍由公司完成。",
    )
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(8)
    r = cap.add_run("图 1  当前代码架构、数据主路径与公司外部依赖")
    set_run_font(r, 9, False, GRAY)
    doc.add_heading("业务实施计划", level=2)
    for item in [
        "用户在正式小程序完成微信登录，阅读公司批准的协议，并在每次人脸处理前作单独同意。",
        "照片进入私有对象存储，服务端只向供应商签发短时 URL；任务、作品和下载均绑定 ownerId。",
        "生成前后执行内容安全检查；生成成功后写入可见 AI 标识、内容编号、服务者编码和模型备案引用。",
        "作品以私有短时链接交付；用户可删除作品、撤回人脸授权或注销账号；本地删除与供应商删除分别留痕。",
        "支付只在公司商户、价格、退款、验签、幂等、补单和对账全部验收后开放。",
    ]:
        add_number(doc, item)
    doc.add_heading("网络与信息安全措施", level=2)
    for item in [
        "身份与权限：生产强制微信身份；对象/任务/订单绑定用户；内部运维接口使用独立令牌；管理员动作审计。",
        "存储与传输：生产强制 HTTPS、私有 OSS、5 分钟短时签名；CORS 精确白名单；出站 URL 阻断私网/localhost SSRF。",
        "应用安全：CSP、HSTS、X-Frame-Options、no-store、请求大小限制、限流、幂等与支付回调验签。",
        "数据生命周期：输入/输出默认 24 小时；定时清理、删除失败告警和供应商副本待办；未确认供应商删除时返回部分完成。",
        "发布安全：CI、语法/lint/构建/测试、SBOM、依赖审计、源码哈希、生产 readiness；工作树不干净时阻断发布。",
    ]:
        add_bullet(doc, item)

    doc.add_heading("6. C04 域名、备案和正式包技术信息", level=1)
    filing_rows = [
        ["应用名称", "乐颜秀", "已确定；公司核对商标/重名"],
        ["运营主体", f"{COMPANY_NAME} / {COMPANY_CODE}", "来自既有公司材料；提交前核营业执照"],
        ["当前客户端", "React 19 + Vite H5", "仅封闭测试，不是原生小程序包"],
        ["计划首发", "微信小程序（技术推荐）", "待公司签字"],
        ["小程序 AppID", "【待公司提供】", "必须公司主账号生成，技术使用子权限"],
        ["正式域名", "【待公司购买、实名、备案】", "用于 PUBLIC_BASE_URL、CORS、合法域名"],
        ["服务器/接入商/IP", "当前为测试 CloudBase 域名；生产资源未冻结", "公司云账号冻结后由技术出最终 IP/接入商"],
        ["小程序版本/包哈希", "【尚无正式原生包】", "完成客户端后生成版本号、签名和 SHA-256"],
        ["后端", "Node.js + Hono；REST API；私有对象/任务/合规台账", "接口矩阵见附件 03"],
        ["图标/截图/审核账号", "【待公司批准视觉与审核联系人】", "技术在正式包完成后输出商店材料包"],
        ["备案展示", "MINIPROGRAM_RECORD_NO / ICP_RECORD_NO", "取得后由技术配置并在显著位置展示"],
    ]
    add_table(doc, ["字段", "当前值", "状态/处理"], filing_rows, [1800, 3300, 4260], 9.3)
    add_callout(doc, "不能提前伪造", "当前不能提供小程序包名、AppID、签名指纹、正式服务器 IP、备案号或安装包哈希。这些必须在公司账号与首发渠道冻结后生成。附件 06/07 已准备字段和代码落点。", PALE_RED, RED)

    doc.add_heading("7. C05/C06 安全职责、官方账号与最小权限", level=1)
    role_rows = [
        ["公司平台所有者", "法人/公司指定管理员", "域名、云、微信、支付、商店主账号；MFA和找回", "不得共享主密码；审批子账号"],
        ["技术负责人", "【公司填写姓名】", "代码仓库维护、部署审批、生产变更和回滚", "不持有法人实名和公司主账号"],
        ["云运维", "【姓名/替补】", "部署、日志、监控、私有存储与密钥引用", "仅生产所需最小权限；操作留痕"],
        ["安全/数据事件负责人", "【公司填写】", "漏洞、越权、数据泄露、删除失败处置", "有停服/下架权限与应急通讯录"],
        ["内容安全负责人", "【公司填写】", "审核策略、人工复核、申诉和紧急下架", "不允许开发人员自行判定法律边界"],
        ["客服/退款负责人", "【公司填写】", "投诉、注销、退款和用户权利请求", "按批准 SLA 处理，结果回写台账"],
        ["财务对账", "【公司填写】", "商户、价格、开票、日对账和异常订单", "技术只提供系统数据，不替财务审批"],
    ]
    add_table(doc, ["角色", "责任人", "系统权限/职责", "控制要求"], role_rows, [1600, 1850, 3300, 2610], 8.8)
    doc.add_heading("应急联系表（公司填写后交技术配置）", level=2)
    add_table(doc, ["领域", "主联系人", "电话/邮箱", "替补", "SLA"], [[x, "________", "________", "________", "________"] for x in ["技术值班", "数据事件", "内容安全", "客服退款", "财务对账"]], [1500, 1900, 2200, 1800, 1960], 9.2)

    doc.add_heading("8. C07 订单、支付、退款与对账实施方案", level=1)
    add_bullet(doc, "状态：服务端已具备产品读取、订单创建、支付回调验签、事件幂等、权益发放、退款回收、恢复购买和对账接口；前端支付按钮禁用。")
    add_bullet(doc, "状态流：pending → paid → entitlement grant；refunded → revoke；生成失败另行退还一次创作权益。重复 eventId 不重复发货。")
    add_bullet(doc, "生产条件：PAYMENT_MODE=live、公司商户号、PAYMENT_PROVIDER、至少 32 字符的回调密钥、已批准产品 JSON、沙箱和生产回调验收、财务日对账差异=0。")
    add_bullet(doc, "公司需批准：产品名称、价格（分）、权益次数/有效期、退款时限、已消费权益处理、发票、客服入口和异常对账责任人。")
    payment_rows = [
        ["月卡/年卡/季卡测试价格", "界面存在但购买按钮禁用", "不得作为正式价格或营销承诺"],
        ["订单台账", "已实现", "公司商品配置后启用"],
        ["回调验签/幂等", "已实现通用契约", "需对接选定支付方真实签名规范"],
        ["退款回收/对账", "已实现账本逻辑", "需商户沙箱、生产小额单和财务签字"],
        ["iOS IAP", "未实现", "若首发 iOS 数字权益，必须另行按 Apple 规则设计"],
    ]
    add_table(doc, ["事项", "当前状态", "上线要求"], payment_rows, [2300, 2600, 4460], 9.4)

    doc.add_heading("9. C08 供应商、模型、数据处理与版权事实", level=1)
    add_callout(doc, "证据解释", "环境盘点显示阿里云、腾讯云、火山引擎、百炼和 DeepSeek 的凭据均存在；这只证明技术账号中有凭据，不证明公司合同、DPA、模型备案、删除承诺、商业授权或逐功能验收已经完成。所有既有密钥应在公司账号内轮换。", PALE_AMBER, AMBER)
    provider_summary = [
        ["视频融合", "阿里云当前主配置；腾讯/火山备选", "模板+用户人脸；区域上海/广州/北京", "合同/DPA/删除/备案/30样本"],
        ["照片修复/年龄/效果", "阿里 VIAPI、腾讯、百炼、火山候选", "人脸照片+参数/提示词", "每入口锁定唯一模型/版本/成本/质量"],
        ["分享文案", "DeepSeek 默认（有密钥时）/混元备选", "仅作品文字描述，不应上传照片", "区域、日志、训练使用和删除条款"],
        ["内容安全", "尚无生产外部适配器", "输入/输出审核", "采购、策略批准、50组对抗样本"],
    ]
    add_table(doc, ["能力", "当前技术事实", "数据/区域", "公司需取得"], provider_summary, [1700, 2650, 2350, 2660], 9.0)
    add_bullet(doc, "完整字段见附件 04；采购/法务应逐行确认 provider、model、version、region、保存期、训练使用、转委托、删除方式、备案号和商业使用。")
    add_bullet(doc, "模板资产必须进入 LICENSED_ASSET_IDS：视频、音乐、人像、封面、字体均需资产编号、权利人、授权地域/期限/渠道和审批人。未登记模板在生产被拒绝。")

    doc.add_heading("10. C09 隐私、内容安全、客服与事件技术事实", level=1)
    privacy_rows = [
        ["首次基础同意", "版本化同意接口已实现", "当前 H5 为测试确认框；正式文本和页面待公司批准"],
        ["人脸单独同意", "每次生成人脸处理前检查并记录", "公司批准目的、数据类型、供应商和本人/授权口径"],
        ["撤回/删除/注销", "设置页和服务端接口已实现", "供应商未确认删除时明确返回部分完成，不假报成功"],
        ["公开合规信息", "/api/public/compliance + 设置页入口已实现", "公司配置隐私/协议/第三方 URL、客服、PIPIA、模型公示"],
        ["内容安全", "本地规则、人工审核/申诉/下架契约已实现", "生产外部图像/视频审核尚未接入，readiness 阻断"],
        ["AI 标识", "图片/视频可见标识和元数据写入实测通过", "公司提供服务者编码和真实模型备案引用"],
        ["客服/事件", "审计、监控、告警演练接口已实现", "公司指定人员、通知渠道、SLA并完成真实演练"],
    ]
    add_table(doc, ["事项", "技术现状", "公司必须补齐"], privacy_rows, [2200, 3200, 3960], 9.1)
    add_bullet(doc, "数据字段、目的、保存/删除和接收方见附件 05，可直接交律师起草隐私政策、第三方清单和 PIPIA。")
    add_bullet(doc, "生产配置新增并强制校验：PRIVACY_POLICY_URL、USER_AGREEMENT_URL、THIRD_PARTY_LIST_URL、SUPPORT_CONTACT、PIPIA_REFERENCE、AI_SERVICE_DISCLOSURES_JSON。")

    doc.add_heading("11. 公司补充与签字表", level=1)
    decision_rows = [
        ["首发渠道/地区/收费", "【公司填写】", "业务负责人：______ 日期：______"],
        ["域名/AppID/备案负责人", "【公司填写】", "行政/运营：______ 日期：______"],
        ["隐私/协议/PIPIA/保存期", "【版本号和URL】", "法务/负责人：______ 日期：______"],
        ["供应商/模型/备案/删除条款", "【逐供应商确认】", "采购/法务：______ 日期：______"],
        ["价格/退款/开票/对账", "【公司填写】", "财务：______ 日期：______"],
        ["客服/内容安全/数据事件联系人", "【姓名、电话、替补、SLA】", "负责人：______ 日期：______"],
        ["上线结论", "[ ]继续封闭测试  [ ]满足条件后进入正式提交", "公司：______ 技术：______"],
    ]
    add_table(doc, ["确认项", "公司填写", "签字"], decision_rows, [2800, 3300, 3260], 9.2)
    add_callout(doc, "当前签字建议", "选择“继续封闭测试”。只有正式小程序包、公司域名/账号、外部审核、私有 OSS 审计、供应商合同/删除、30 样本、支付（如收费）和发布漏洞全部闭环后，才能改为正式提交。", PALE_RED, RED)

    doc.add_page_break()
    doc.add_heading("12. 附件索引与验收口径", level=1)
    attachments = [
        ["01", "ICP业务界定技术事实说明.docx", "公司提交官方咨询的技术附件", "公司补联系人并正式提交"],
        ["02", "系统架构与数据流图.png", "许可/备案/隐私/供应商审查", "与生产配置一致"],
        ["03", "接口与权限矩阵.csv", "安全职责和最小权限", "公司账号角色落地"],
        ["04", "供应商与功能映射.csv", "采购、DPA、模型公示", "逐行合同/备案/区域确认"],
        ["05", "数据字段-目的-保存删除清单.csv", "隐私政策/PIPIA/第三方清单", "公司批准保存期"],
        ["06/07", "公司补充字段表/生产配置模板", "公司向技术交付批准值", "密钥只进密钥系统"],
        ["08", "测试与发布证据目录", "技术复核和上线签字", "非零项必须关闭或正式例外审批"],
    ]
    add_table(doc, ["编号", "文件", "用途", "验收"], attachments, [650, 2900, 2850, 2960], 9.0)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    r = p.add_run("文件边界：")
    set_run_font(r, 10, True, GRAY)
    r = p.add_run("本材料册记录技术事实和待办，不是法律意见，不代替监管部门、平台、供应商或律师的正式结论。")
    set_run_font(r, 10, False, GRAY)
    doc.save(MAIN_DOCX)


def create_icp_doc() -> None:
    doc = Document()
    configure_document(doc, "乐颜秀 ICP 业务界定技术事实说明")
    section = doc.sections[0]
    section.top_margin = Inches(0.55)
    section.bottom_margin = Inches(0.55)
    add_title_block(doc, "乐颜秀 ICP 业务界定技术事实说明", "供北京属地通信管理部门官方咨询使用；请按实际事实判断，不预设许可结论", "待公司提交官方咨询")
    add_callout(doc, "咨询目的", "请根据下列真实业务和技术事实，书面确认该自营 AI 影像加工服务是否需要申请增值电信业务经营许可证（如需，请明确业务种类、申请范围和需补材料）。", PALE_BLUE, BLUE)
    doc.add_heading("一、主体与产品", level=2)
    for text in [
        f"运营主体：{COMPANY_NAME}；统一社会信用代码：{COMPANY_CODE}。",
        "产品名称：乐颜秀；当前为 React/Vite H5 封闭测试，计划首发微信小程序，正式 AppID/域名/备案号尚未取得。",
        "服务对象：普通个人用户；用户处理本人照片或已获授权照片，生成照片唱歌、跳舞、语录视频，以及修复、年龄变化、头像/艺术效果等图片。",
    ]:
        add_bullet(doc, text)
    doc.add_heading("二、经营与内容边界", level=2)
    for text in [
        "公司自营工具，不接入第三方商家，不向第三方开放店铺或交易场所。",
        "首期不提供用户作品公开发布、社区、直播或公众信息分发；结果以私有短时链接交付用户，由用户自行下载分享。",
        "推荐页是公司编辑选择的模板，不使用无证据的使用量、成交量或虚构热度。",
        "当前 PAYMENT_MODE=closed_test，未开放真实收款；未来可能采用单次、次数包或订阅，具体方式由公司另行批准。",
    ]:
        add_bullet(doc, text)
    doc.add_heading("三、技术与数据流", level=2)
    add_bullet(doc, "用户登录并完成基础同意及人脸单独同意 → 照片进入私有对象存储 → 服务端向 AI 供应商签发短时 URL → 生成前后内容审核 → 写入 AI 可见标识和元数据 → 私有结果返回用户。")
    add_bullet(doc, "视频当前主配置为阿里云；照片能力涉及阿里云/腾讯云/火山引擎/百炼候选；分享文案可调用 DeepSeek。最终生产供应商、模型、区域和备案号须以公司合同和实际配置为准。")
    add_bullet(doc, "输入/输出代码默认保存 24 小时；用户可立即删除、撤回人脸授权、注销账号；供应商副本删除须以合同/API 回执确认。")
    doc.add_heading("四、拟请官方确认", level=2)
    for text in [
        "在上述“公司自营 AI 影像加工、无第三方入驻、无用户公开内容分发”的模式下，如向用户收取单次/次数/订阅费用，是否属于需取得 B25 信息服务业务（仅限互联网信息服务）经营许可的业务？",
        "若无需经营许可，除 ICP/小程序备案、AI 生成合成内容标识、人脸信息保护及平台审核外，是否还有本业务对应的通信管理前置事项？",
        "如未来增加用户公开作品、第三方模板/商家或广告分发，是否应在功能上线前重新进行业务界定？",
    ]:
        add_number(doc, text)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    r = p.add_run("公司联系人：")
    set_run_font(r, 10.5, True, BLACK)
    r = p.add_run("【姓名/电话/邮箱】     技术联系人：【姓名/电话/邮箱】     提交日期：【____年__月__日】")
    set_run_font(r, 10.5, False, BLACK)
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run("附件建议：系统架构与数据流图、供应商与功能映射、数据字段与保存删除清单。")
    set_run_font(r, 9.5, False, GRAY)
    doc.save(ICP_DOCX)


def build_hash_manifest() -> None:
    lines = []
    for path in sorted(OUT.rglob("*")):
        if not path.is_file() or path.name in {"09-文件哈希清单.sha256"} or path.suffix.lower() == ".zip":
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(OUT).as_posix()}")
    (OUT / "09-文件哈希清单.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_zip() -> Path:
    zip_path = PROJECT / "部署" / "乐颜秀公司办理技术材料包-2026-08-29.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(OUT.rglob("*")):
            if path.is_file():
                archive.write(path, Path(OUT.name) / path.relative_to(OUT))
    return zip_path


def main() -> None:
    evidence = collect_evidence()
    create_support_files(evidence)
    create_architecture_diagram()
    create_main_doc(evidence)
    create_icp_doc()
    build_hash_manifest()
    zip_path = build_zip()
    print(json.dumps({
        "outputDir": str(OUT),
        "mainDocx": str(MAIN_DOCX),
        "icpDocx": str(ICP_DOCX),
        "zip": str(zip_path),
        "evidenceSummary": evidence["summary"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
