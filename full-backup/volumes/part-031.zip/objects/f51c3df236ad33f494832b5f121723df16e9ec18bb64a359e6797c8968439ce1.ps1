$ErrorActionPreference = 'Stop'
$source = 'D:\Documents\kimi\workspace\乐颜秀-换脸App项目\部署\乐颜秀微信小程序付费开通公司办理手册-2026-09-21.docx'
$qa = 'D:\Documents\kimi\workspace\payment-doc-qa'
New-Item -ItemType Directory -Force -Path $qa | Out-Null
$copy = Join-Path $qa 'payment.docx'
$pdf = Join-Path $qa 'payment.pdf'
Copy-Item -LiteralPath $source -Destination $copy -Force
$app = New-Object -ComObject KWPS.Application
$app.Visible = $false
try {
    $document = $app.Documents.Open($copy)
    try {
        $document.ExportAsFixedFormat($pdf, 17)
    } finally {
        $document.Close($false)
    }
} finally {
    $app.Quit()
}
Write-Output $pdf
