from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


OUT = Path(r"D:\Documents\kimi\workspace\乐颜秀-换脸App项目\部署\乐颜秀微信小程序付费开通公司办理手册-2026-09-21.docx")
INK = RGBColor(35, 44, 52)
MUTED = RGBColor(92, 105, 116)
ACCENT = RGBColor(36, 99, 124)


def font(run, size=10, bold=False, color=INK):
    run.font.name = "Microsoft YaHei"
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for attr in ("ascii", "hAnsi", "eastAsia"):
        rfonts.set(qn(f"w:{attr}"), "Microsoft YaHei")


def para(doc, text="", *, style=None, bold_prefix=None, after=5, keep=False):
    p = doc.add_paragraph(style=style)
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.35
    p.paragraph_format.keep_with_next = keep
    if bold_prefix and text.startswith(bold_prefix):
        font(p.add_run(bold_prefix), bold=True)
        font(p.add_run(text[len(bold_prefix):]))
    else:
        font(p.add_run(text))
    return p


def bullet(doc, text):
    return para(doc, text, style="List Bullet", after=2)


def head(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    p.paragraph_format.space_before = Pt(13 if level == 1 else 7)
    p.paragraph_format.space_after = Pt(5)
    p.paragraph_format.keep_with_next = True
    font(p.add_run(text), 14 if level == 1 else 11, True, ACCENT)
    return p


def table(doc, headers, rows, widths):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    for i, width in enumerate(widths):
        t.columns[i].width = Cm(width)
    for j, values in enumerate([headers] + rows):
        row = t.rows[0] if j == 0 else t.add_row()
        pr = row._tr.get_or_add_trPr()
        pr.append(OxmlElement("w:cantSplit"))
        if j == 0:
            pr.append(OxmlElement("w:tblHeader"))
        for i, value in enumerate(values):
            cell = row.cells[i]
            cell.width = Cm(widths[i])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr = cell._tc.get_or_add_tcPr()
            shd = OxmlElement("w:shd")
            shd.set(qn("w:fill"), "E9F1F4" if j == 0 else ("F8FAFB" if j % 2 == 0 else "FFFFFF"))
            tcpr.append(shd)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.22
            if j == 0:
                p.paragraph_format.keep_with_next = True
            font(p.add_run(value), 8.7, j == 0)
    para(doc, "", after=1)
    return t


def check(doc, text):
    para(doc, "□ " + text, after=3)


doc = Document()
sec = doc.sections[0]
sec.page_width = Cm(21)
sec.page_height = Cm(29.7)
sec.top_margin = Cm(2.0)
sec.bottom_margin = Cm(1.8)
sec.left_margin = Cm(2.0)
sec.right_margin = Cm(2.0)
sec.header_distance = Cm(0.8)
sec.footer_distance = Cm(0.9)

normal = doc.styles["Normal"]
normal.font.name = "Microsoft YaHei"
normal.font.size = Pt(10)
normal.font.color.rgb = INK
normal.paragraph_format.space_after = Pt(5)

p = doc.add_paragraph(style="Title")
p.paragraph_format.space_after = Pt(10)
font(p.add_run("乐颜秀微信小程序付费开通公司办理手册"), 21, True, INK)
para(doc, "公司办理版  2026年9月21日", after=12)
para(doc, "本手册交给公司负责人、财务及运营人员执行。目标是在保持小程序免费版上线安排不变的前提下，完成支付业务分类确认、商户开户与产品决策，并将真实资料安全交付技术联调。当前代码仍关闭真实支付；公司不能只因小程序审核通过就开启收费。", after=11)

head(doc, "先做的四件事")
table(doc, ["顺序", "公司动作", "完成证据"], [
    ["1", "整理真实业务描述并向微信小程序或微信支付官方提交书面问询，确认AI生成次数和会员应接哪种支付能力，以及iOS和Android的规则。", "工单编号、原文、官方书面回复截图或导出件"],
    ["2", "核实并认证公司小程序主体，申请或核查公司名下微信支付普通商户号。", "小程序AppID、认证状态、商户号及权限状态"],
    ["3", "批准商品方案、定价、有效期、退费及客服规则。首期建议只做非自动续费的次数包。", "公司签字的商品和退款决策单"],
    ["4", "由超级管理员绑定商户号与AppID，开通获准的产品权限，为技术开独立最小权限账号。", "关联成功截图、技术账号授权记录"],
], [1.2, 10.4, 5.4])

head(doc, "责任分配")
table(doc, ["角色", "负责", "不应代办"], [
    ["公司负责人", "业务分类问询、经营方式和商品决策、开户与合同签署、最终启用批准", "不将商户主账号密码交技术"],
    ["财务", "结算账户、费率、退款审批、账单与到账核对、发票和税务处理", "不让技术人员以个人账户代收款"],
    ["运营客服", "商品文案、服务说明、投诉、退款受理、审核材料", "不在平台未确认前发布收费入口"],
    ["技术", "接口、签名与回调、订单权益、对账自动化和测试", "不替公司决定业务类目和商业条款"],
], [2.6, 8.7, 5.7])

head(doc, "步骤一 确认微信支付业务分类")
para(doc, "这是后续开发的前置决策。AI图片和视频生成、次数包及会员是数字化服务，不能因为技术接口可用就直接按实物商品接普通小程序支付。公司应通过小程序后台或微信支付官方渠道提交以下事实描述，要求书面回复适用的产品权限。")
para(doc, "建议提交文本", keep=True)
para(doc, "我司REDACTED_COMPANY_NAME运营微信小程序“乐颜秀”。用户上传本人或已获授权的人像照片，选择模板，由我司接入AI服务生成图片或视频，结果仅供该用户下载与分享，不销售实体商品。计划出售固定次数的生成服务，暂不自动续费，不开放第三方商家入驻或公开作品社区。请确认：该业务应申请普通小程序支付、虚拟支付或其他指定能力？Android和iOS分别允许怎样的购买入口及权益使用？是否有类目、订单发货管理、展示文案及审核材料要求？如改为包月会员，是否需要另行申请订阅或自动扣费能力？请提供对应官方规则及书面结论。", after=8)
check(doc, "记录工单编号、提交日期、回复原文、适用AppID和负责人；不要只留电话口头答复。")
check(doc, "如回复要求不同系统使用不同支付能力，技术按官方结果拆分流程；不得用外链或二维码绕过规则。")
check(doc, "如尚无明确回复，免费版本继续运行，正式版隐藏收费入口。")

head(doc, "步骤二 开通小程序和商户号")
para(doc, "先核对现有账号，避免重复开户。公司主体、小程序认证主体、结算账户应由财务和超级管理员逐项核对。微信官方流程允许AppID与商户号并行申请，但小程序支付权限要求小程序完成认证。")
check(doc, "微信公众平台核对小程序名称、AppID、认证状态、主体与管理员。")
check(doc, "微信支付商户平台核对是否已有公司商户号、主体信息、结算账户、超级管理员与待处理风险提示。")
check(doc, "无商户号时，以公司主体申请普通商户号；如已有商户号，确认其小程序支付产品权限和经营类目。申请材料以平台页面当时要求为准，通常需营业执照、法人及经办人身份信息、结算账户和业务说明。")
check(doc, "在商户平台发起AppID关联，并由公众平台管理员确认绑定；保存两端成功截图。")
check(doc, "核对经营类目、费率、结算周期、支付权限及退款能力是否与书面业务分类答复一致。")
para(doc, "公司不要自行将商户号密码、短信验证码、法人证件照片或银行卡信息发到开发群。技术只需要单独授权的技术负责人账号及指定接口参数。", after=8)

head(doc, "步骤三 批准商品和售后方案")
para(doc, "技术可以先按次数包实现，但名称、价格与履约规则必须由公司批准。次数包建议比月卡、季卡和自动续费先上线，因为交付边界和退款核算更清楚；这只是产品建议，不是平台准入结论。")
table(doc, ["需决定", "公司填写"], [
    ["首期售卖形式", "□ 单次生成  □ 固定次数包  □ 非自动续费会员  □ 其他：________"],
    ["商品", "商品名称：________  每包含次数：________  含图片/视频的范围：________"],
    ["价格", "含税售价：________ 元；对应平台商品描述：________________"],
    ["履约", "支付成功后发放时间：________；有效期：________；余额展示方式：________"],
    ["失败处理", "未开始/生成失败：返还次数；原路资金退款触发条件：________________"],
    ["退款", "未使用、部分使用、已使用权益的处理规则和时限：________________"],
    ["售后", "客服入口：________；投诉受理人：________；发票及抬头处理：________"],
], [3.5, 13.5])
para(doc, "批准人：____________  财务复核：____________  日期：____________", after=8)

head(doc, "步骤四 给技术安全交付资料")
para(doc, "公司超级管理员在商户平台给技术负责人开独立账号并授权必要权限。商户私钥、APIv3密钥等敏感资料只通过公司密钥系统或一次性加密交付，不放进Word、微信群、邮箱正文或代码仓库。")
table(doc, ["字段或证据", "公司填写或办理", "交付方式"], [
    ["小程序AppID、商户号mchid", "AppID：________  mchid：________", "企业工单，可供技术核对"],
    ["产品权限与AppID关联", "权限状态：________  关联日期：________", "截图和工单编号"],
    ["支付业务分类与iOS规则", "官方答复编号：________  适用产品：________", "完整书面答复"],
    ["商户API证书序列号", "序列号：________  到期日：________", "技术负责人账号或工单"],
    ["商户私钥及APIv3密钥", "已由超级管理员创建：□ 是  □ 否", "公司密钥系统，不在表内填值"],
    ["微信支付公钥或平台证书", "选用方式：________  标识：________", "技术负责人账号或密钥系统"],
    ["正式回调域名与通知地址", "公司批准的域名：________________", "运维工单，与备案和HTTPS配置核对"],
    ["账单与退款权限", "财务账号：________  技术只读/接口权限：________", "最小权限授权记录"],
], [4.1, 7.7, 5.2])
para(doc, "技术收到资料后应完成微信APIv3真实下单、验签解密、主动查单、退款、账单下载、差异告警及真机验收；公司不得仅将环境变量由 closed_test 改为 live 就宣称收款准备完成。", after=8)

head(doc, "步骤五 验收后再申请付费版本审核")
check(doc, "技术提交Android及iOS两端真机录屏和支付测试单，覆盖成功、取消、超时、重复回调、金额不符、生成失败返次、资金退款。")
check(doc, "财务用微信交易账单与内部订单、权益和银行入账核对，差异为零或有已审批的解释。")
check(doc, "运营检查商品名称、价格、服务说明、退款入口、客服渠道及平台要求的订单发货管理。")
check(doc, "法务或公司负责人确认用户协议、隐私政策和业务分类答复对应同一正式版本。")
check(doc, "公司签字批准后，技术打开支付开关、提审付费版本；审核通过后先小范围放量，再观察异常与投诉。")
para(doc, "批准：________  财务：________  技术：________  版本：________  日期：________", after=8)

head(doc, "上线后的公司例行工作")
table(doc, ["频率", "公司责任"], [
    ["每日", "财务核对前一日交易、退款和到账；客服处理支付成功未到账权益、生成失败和投诉；异常通知技术。"],
    ["每周", "运营检查商品展示与平台通知；技术和财务共同复核对账差异和退款未完结项。"],
    ["变更时", "改价、增加会员自动续费、扩大服务范围、更换主体或收款方式前，重新确认平台权限、条款和提审要求。"],
], [2, 15])

head(doc, "官方资料与记录留存")
para(doc, "微信支付小程序支付开发接入准备  https://pay.wechatpay.cn/doc/v3/merchant/4015459512")
para(doc, "微信支付商户号与AppID绑定  https://pay.wechatpay.cn/doc/v3/merchant/4013287504")
para(doc, "微信支付开发必要参数  https://pay.wechatpay.cn/doc/v3/merchant/4013070756")
para(doc, "微信支付小程序下单与回调  https://pay.wechatpay.cn/doc/v3/merchant/4012791870")
para(doc, "微信支付账单下载  https://pay.wechatpay.cn/doc/v3/merchant/4013071218")
para(doc, "本手册只处理微信小程序收费的公司办理事项。你们此前确认的ICP经营许可证结论不在此重新判断；小程序备案、支付产品准入、内容合规和用户权益仍须分别完成。", after=0)

footer = sec.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
font(footer.add_run("乐颜秀  公司办理材料  2026年9月21日"), 8, False, MUTED)
OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(OUT)
print(OUT)
